import csv
import os
import subprocess
from datetime import date, datetime

import pyodbc

REPO = r"D:\DONE\report"
CONNECTION_STRING = "DSN=pbi_supplier"

REPORTS = {
    "data_tool_outbound_report": "outbound.csv",
    "data_tool_inbound_report": "inbound.csv",
    "data_tool_putaway_pending": "putaway.csv",
    "data_tool_pda_phone_num": "pda.csv",
}


def run_git(command):
    """Run a git command and display its output."""
    print(f"\n> {' '.join(command)}")

    result = subprocess.run(
        command,
        cwd=REPO,
        capture_output=True,
        text=True,
    )

    if result.stdout:
        print(result.stdout)

    if result.stderr:
        print(result.stderr)

    if result.returncode != 0:
        raise RuntimeError(f"Git command failed: {' '.join(command)}")


def cell(value):
    """One view value -> CSV text, exactly as the view returns it."""
    if value is None:
        return ""
    if isinstance(value, float) and value.is_integer():
        return str(int(value))                    # 3.0 from the driver -> "3"
    if isinstance(value, datetime):
        if value.time() == datetime.min.time():
            return value.strftime("%Y-%m-%d")     # date stored as datetime -> "2026-11-14"
        return value.strftime("%Y-%m-%d %H:%M:%S")
    if isinstance(value, date):
        return value.strftime("%Y-%m-%d")
    return str(value)


def export_reports():
    print("Connecting to database...")

    with pyodbc.connect(CONNECTION_STRING) as conn:
        for table, filename in REPORTS.items():
            print(f"Exporting {table}...")

            cursor = conn.cursor()
            cursor.execute(f"SELECT * FROM {table}")
            header = [col[0] for col in cursor.description]
            rows = cursor.fetchall()

            output = os.path.join(REPO, filename)
            # utf-8 without BOM, CRLF line ends, quotes only where needed (same as before)
            with open(output, "w", encoding="utf-8", newline="") as f:
                writer = csv.writer(f, lineterminator="\r\n")
                writer.writerow(header)
                for row in rows:
                    writer.writerow([cell(v) for v in row])

            print(f"Saved: {output} ({len(rows)} rows)")


def push_to_github():
    message = f"Update data {datetime.now():%Y-%m-%d %H:%M}"

    run_git(["git", "add", "."])
    run_git(["git", "commit", "--allow-empty", "-m", message])

    run_git(["git", "push", "--force-with-lease", "origin", "main"])


def main():
    print("=" * 60)
    print("REPORT EXPORT")
    print("=" * 60)

    export_reports()
    push_to_github()

    print("\nSUCCESS - GitHub updated.")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print("\nFAILED")
        print(e)
